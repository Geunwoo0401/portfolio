package com.kgw.matzip.enums;

public enum VerifyRecoverEmailCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}