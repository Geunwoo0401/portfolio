package com.kgw.matzip.enums;

public enum RecoverPasswordResult {
    FAILURE,
    SUCCESS
}