package com.kgw.matzip.enums;

public enum CheckNicknameResult {
    DUPLICATE,
    OKAY
}