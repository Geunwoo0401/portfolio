package com.kgw.matzip.enums;

public enum SendRecoverEmailCodeResult {
    FAILURE,
    SUCCESS
}