package com.kgw.matzip.enums;

public enum VerifyRegisterContactCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}