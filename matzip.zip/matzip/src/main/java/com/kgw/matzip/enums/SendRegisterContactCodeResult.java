package com.kgw.matzip.enums;

public enum SendRegisterContactCodeResult {
    FAILURE,
    FAILURE_DUPLICATE,
    SUCCESS
}