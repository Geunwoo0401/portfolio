package com.kgw.matzip.enums;

public enum VerifyRegisterEmailCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}