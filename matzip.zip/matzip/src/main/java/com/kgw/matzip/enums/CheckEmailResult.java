package com.kgw.matzip.enums;

public enum CheckEmailResult {
    DUPLICATE,
    OKAY
}