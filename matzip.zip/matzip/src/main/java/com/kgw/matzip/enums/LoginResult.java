package com.kgw.matzip.enums;

public enum LoginResult {
    FAILURE,
    FAILURE_SUSPENDED,
    FAILURE_EMAIL_NOT_VERIFIED,
    SUCCESS
}