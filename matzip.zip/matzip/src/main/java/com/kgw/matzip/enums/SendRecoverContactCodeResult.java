package com.kgw.matzip.enums;

public enum SendRecoverContactCodeResult {
    FAILURE,
    SUCCESS
}