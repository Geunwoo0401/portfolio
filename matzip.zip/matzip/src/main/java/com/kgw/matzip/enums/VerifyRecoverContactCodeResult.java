package com.kgw.matzip.enums;

public enum VerifyRecoverContactCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}