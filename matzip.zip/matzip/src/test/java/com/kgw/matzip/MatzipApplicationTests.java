package com.kgw.matzip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatzipApplicationTests {

	@Test
	void contextLoads() {
	}

}
