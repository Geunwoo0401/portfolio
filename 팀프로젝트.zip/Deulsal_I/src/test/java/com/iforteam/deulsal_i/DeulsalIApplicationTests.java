package com.iforteam.deulsal_i;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeulsalIApplicationTests {

	@Test
	void contextLoads() {
	}

}
