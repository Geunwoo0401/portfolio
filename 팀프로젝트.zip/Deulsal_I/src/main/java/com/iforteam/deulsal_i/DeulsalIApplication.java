package com.iforteam.deulsal_i;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeulsalIApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeulsalIApplication.class, args);
	}

}
