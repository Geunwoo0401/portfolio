package com.iforteam.deulsal_i.enums;

public enum EntrepreneurRegisterResult {
    FAILURE,
    FAILURE_PROCESSING,
    SUCCESS
}
