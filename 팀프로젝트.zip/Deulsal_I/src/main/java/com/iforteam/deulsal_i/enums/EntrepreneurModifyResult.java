package com.iforteam.deulsal_i.enums;

public enum EntrepreneurModifyResult {
    FAILURE,
    FAILURE_PROCESSING,
    SUCCESS
}
