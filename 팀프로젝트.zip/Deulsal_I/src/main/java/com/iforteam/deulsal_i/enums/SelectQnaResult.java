package com.iforteam.deulsal_i.enums;

public enum SelectQnaResult {
    SUCCESS, //답변 존재
    FAILURE  // 답변 비존재
}
