package com.iforteam.deulsal_i.enums;

public enum UserCheckNicknameResult {
    DUPLICATE,
    OKAY
}
