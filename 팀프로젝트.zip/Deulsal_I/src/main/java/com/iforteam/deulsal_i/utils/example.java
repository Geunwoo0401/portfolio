package com.iforteam.deulsal_i.utils;

public class example {
}
