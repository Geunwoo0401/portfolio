package com.iforteam.deulsal_i.enums;

public enum example {
}
