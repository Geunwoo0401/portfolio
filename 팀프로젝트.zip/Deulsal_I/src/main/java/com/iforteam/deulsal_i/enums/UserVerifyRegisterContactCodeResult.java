package com.iforteam.deulsal_i.enums;

public enum UserVerifyRegisterContactCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}
