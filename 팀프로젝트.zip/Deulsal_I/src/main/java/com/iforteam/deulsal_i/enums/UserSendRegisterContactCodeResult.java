package com.iforteam.deulsal_i.enums;

public enum UserSendRegisterContactCodeResult {

    FAILURE,
    FAILURE_DUPLICATE,
    SUCCESS
}
