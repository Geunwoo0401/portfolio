package com.iforteam.deulsal_i.enums;

public enum UserSendRecoverEmailCodeResult {
    FAILURE,

    FAILURE_NO_USERS,

    SUCCESS
}
