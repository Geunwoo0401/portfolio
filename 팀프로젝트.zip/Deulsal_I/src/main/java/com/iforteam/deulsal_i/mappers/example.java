package com.iforteam.deulsal_i.mappers;

public interface example {
}
