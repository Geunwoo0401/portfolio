package com.iforteam.deulsal_i.enums;

public enum UserLoginResult {
    FAILURE,
    FAILURE_DORMANT,
    FAILURE_AUTHORITY,
    SUCCESS,
    SUCCESS_BUSINESS
}
