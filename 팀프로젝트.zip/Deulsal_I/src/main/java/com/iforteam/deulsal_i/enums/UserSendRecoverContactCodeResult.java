package com.iforteam.deulsal_i.enums;

public enum UserSendRecoverContactCodeResult {
    FAILURE,
    FAILURE_NOT_FOUND_CONTACT,

    FAILURE_NO_USERS,

    SUCCESS
}
