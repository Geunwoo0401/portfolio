package com.iforteam.deulsal_i.enums;

public enum ReservationResult {
    FAILURE,
    FAILURE_PROCESSING,
    SUCCESS
}
