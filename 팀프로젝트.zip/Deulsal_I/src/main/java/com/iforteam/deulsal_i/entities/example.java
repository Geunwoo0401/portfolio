package com.iforteam.deulsal_i.entities;

public class example {
}
