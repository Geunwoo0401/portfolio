package com.iforteam.deulsal_i.enums;

public enum UserModifyResult {

    FAILURE,
    FAILURE_NOT_FOUND_USER,
    FAILURE_DUPLICATED,
    SUCCESS
}
