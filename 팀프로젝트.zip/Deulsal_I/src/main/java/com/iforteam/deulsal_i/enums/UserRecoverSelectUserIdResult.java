package com.iforteam.deulsal_i.enums;

public enum UserRecoverSelectUserIdResult {
    FAILURE,
    SUCCESS
}
