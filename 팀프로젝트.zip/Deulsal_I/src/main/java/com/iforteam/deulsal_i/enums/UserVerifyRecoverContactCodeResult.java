package com.iforteam.deulsal_i.enums;

public enum UserVerifyRecoverContactCodeResult {
    FAILURE,
    FAILURE_EXPIRED,
    SUCCESS
}
