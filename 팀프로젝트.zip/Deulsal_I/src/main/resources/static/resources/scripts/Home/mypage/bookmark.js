function moveDetail(index){
    location.href = `/member/detail?index=${index}`
}