function moveDetail(index){
    location.href = `/help/qna/view?index=${index}`
}