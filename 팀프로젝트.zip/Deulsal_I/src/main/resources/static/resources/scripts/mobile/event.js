// contents.searchForm = contents.querySelector('[rel="searchForm"]');
//
// contents.searchForm['search'].addEventListener('keydown', (event) => {
//     if(event.key === 'Enter'){
//         contents.searchForm['searchBtn'].click();
//     }
//     // console.log('searchCriterion');
// });
//
// document.addEventListener('keydown', function(event) {
//     if (event.key === 'Enter') {
//         event.preventDefault();
//     };
// });