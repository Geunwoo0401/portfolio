const contents = document.getElementById('contents');

const refusalList = document.getElementById('refusalList');
