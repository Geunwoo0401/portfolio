let snake = []; // 뱀 객체 ( 뱀의 전체)
let apple; // 사과 객체 (뱀이 먹는 먹이)
const mainCanvas = document.getElementById('main-canvas');
const canvasContext = mainCanvas.getContext('2d');
const DIRECTION = { up: 8, down: 2, left: 4, right: 6};
const scoreHTML = document.getElementById('score'); // HTML의 SCORE 표시 부분을 가져온다
const score = 1; // 사과 먹을 때마다 올려줄 스코어
let frame = 300; // 게임 진행하는 초기속도
let gameID; // 현재 진행하고 있는 게임 ID
let isOver = true; // 게임 오버 상태인지 체크하는 변수

// init_gmame(); //게임 시작 전 초기화
// gameID = setInterval(game_loop, 300); // 처음 시작한 게임 ID를 받아온다

// 뱀의 몸통 (일부) (x좌표, y좌표, 가로길이, 세로길이)
function SnakePart(x, y, w, h, dir) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.dir = dir;
}

function Apple(x, y, w, h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
}

// 게임 시작하기 전에 미리 설정해놓아야하는 부분
function init_game(){
    document.getElementById('game-over').toggleAttribute('hidden');
    // 게임이 시작되었다
    isOver = false;
    // 게임 시작할 때 처음 속도 값 지정
    frame = 300;
    // 게임을 시작하면 SCORE를 0으로 초기화
    scoreHTML.innerText = '0';
    // 게임을 재 시작했을 때를 대비하여 뱀을 다시 생성
    snake = [];
    create_rect(0, 0, mainCanvas.width, mainCanvas.height, 'black'); // 배경그리기
    // 뱀은 뱀 몸통들의 배열 집합( 맨 처음에는 머리 부분을 하나 만들어서 배열에 집어넣는다)
    snake.push(new SnakePart(60, 60, 20, 20, DIRECTION.right));
    // 사과 생성
    create_apple(100, 100);
}

// 사과를 생성하는 함수 (좌료를 받아서 설정)
function create_apple(x, y){
    apple = new Apple(x, y, 20 ,20);
}

// 뱀의 한 부분을 생성하는 함수
function create_part_of_snake() {
    const lastBody = snake[snake.length - 1]; // 현재 꼬리
    const coord = calc_coordinate(lastBody.x, lastBody.y, lastBody.w, lastBody.h, lastBody.dir);
    snake.push(new SnakePart(-coord.x, -coord.y, coord.w, coord.h, lastBody.dir)); // 뱀의 한 몸통을 만든다
}

// 메인 게임이 진행되는 루프
function game_loop(){
    clear_canvas(); // 캔버스 지우기
    move_snake(); // 뱀 이동시키기 (다음 뱀 좌표 계산해놓기)
    draw(); // 메인 캔버스와 뱀 그리기
    check_collision(); // 뱀이 어딘가와 부딪혔는지 체크한다

}

function draw(){
    // 메인 캔버스에 그리기 (배경 그리기)
    create_rect(0, 0, mainCanvas.width, mainCanvas.height, 'black');
    // 사과를 그린다
    create_rect(apple.x, apple.y, apple.w, apple.h, 'red');
    // 뱀을 그린다
    for(let i = 0; i < snake.length; i++){
        create_rect(snake[i].x, snake[i].y,snake[i].w, snake[i].h, 'blue');
    }
}

// canvas에 사각형을 그리는 함수 (x, y, 가로길이, 세로길이
function create_rect(x, y, w, h, color){
    canvasContext.fillStyle = color;
    canvasContext.fillRect(x, y, w, h);
}

// 뱀을 이동시키는 함수
function move_snake() {
    // 현재 뱀이 진행중인 방향을 전달하여, 다음 위치를 결정시킨다
    const newCoord = calc_coordinate(snake[0].x, snake[0].y, snake[0].w, snake[0].h, snake[0].dir);
    // 머리를 새로 생성해서 이동해야할 위치에 집어넣는다
    snake.unshift(new SnakePart(newCoord.x, newCoord.y, newCoord.w, newCoord.h, snake[0].dir));
    snake.pop(); // 꼬리 부분을 제거한다
}

// 현재 진행중인 방향과 위치를 받아와서, 이동해야할 다음 좌표를 계산하는 함수
function calc_coordinate(x, y, w, h, dir){
    switch (dir){
        case DIRECTION.up:
            return { x: x, y: y - h, w: w, h: h};
        case DIRECTION.down:
            return { x: x, y: y + h, w: w, h: h};
        case DIRECTION.left:
            return { x: x - w, y: y, w: w, h: h};
        case DIRECTION.right:
            return { x: x + w, y: y, w: w, h: h};
    }
    return null;
}

// 캔버스의 원하는 위치를 지우는 함수
function clear_canvas() {
    // 캔버스 전부 지운다
    canvasContext.clearRect(0, 0, mainCanvas.width, mainCanvas.height);
}

// 사과 먹었을 떄 스코어를 더해줄 부분
function calc_score(){
    // 내가 정한 점수를 더해준다
    scoreHTML.innerText = +scoreHTML.innerText + score;
}

function game_over() {
    isOver = true; // 게임 오버가 되었다
    document.getElementById('game-over').toggleAttribute('hidden');
    clearInterval(gameID); // 게임 오버로, 게임을 중단시킴
}

// 키보드 방향키를 눌렀을 때, 뱀 머리를 이동시키는 함수 정의
document.addEventListener('keydown', event => {
    switch (event.key){
        case "ArrowUp":      //위 방향키 눌렀을 떄
            snake[0].dir = DIRECTION.up;
            break;
        case "ArrowDown":    // 아래 방향키
            snake[0].dir = DIRECTION.down;
            break;
        case "ArrowLeft":    // 왼쪽
            snake[0].dir = DIRECTION.left;
            break;
        case "ArrowRight":   // 오른쪽
            snake[0].dir = DIRECTION.right;
            break;
        case " ": // space bar
            if(isOver){ // 게임오버 상태라면
                init_game(); // 게임을 초기화
                gameID = setInterval(game_loop, frame); // 시작한 게임 ID를 받아온다
            }
            break;
    }
});

// 충돌을 체크하는 함수( 뱀과 뱀, 사과와 뱀)
function check_collision() {
    // 사과와 뱀이 충돌하였는가? 를 체크
    // 뱀 머리와 사과의 좌표가 같으면 충돌한것이다 (크기와 좌표 범위가 일치하기 떄문에)
    if(apple.x === snake[0].x && apple.y === snake[0].y){
        // 프레임을 낮춰서 종료시킨다음 다시 실행시킨다 (난이도 조절)
        frame -= 15;
        clearInterval(gameID);
        gameID = setInterval(game_loop, frame);
        /** 스코어 부분 **/
        calc_score(); // 스코어를 올려준다
        /** 뱀 부분 **/
        create_part_of_snake(); // 뱀 몸통을 하나 더 챙겨준다
        /** 사과 부분 **/
            // 사과의 다음 위치를 랜덤으로 정해준다
        const appleX = parseInt(Math.random() * 15) * 20;
        const appleY = parseInt(Math.random() * 15) * 20;
        // 사과를 다시 생성한다
        create_apple(appleX, appleY);
    }
    if(snake[0].x < 0 ||  // 왼쪽 충돌
        snake[0].x > mainCanvas.width || // 오른쪽 충돌
        snake[0].y < 0 || // 위쪽 충돌
        snake[0].y >mainCanvas.height){ // 아래쪽 충돌
        // clearInterval(gameID); // 게임 오버로, 게임을 중단시킴
        // alert("GAME OVER");
        game_over();
    }

    // 뱀 머리와 뱀 몸통이 충돌하였는가?
    for(let i = 1; i < snake.length; i++) {
        // 머리 부분 좌표와 몸 부분 어디든 좌표가 일치한다면 충돌한것이다
        if(snake[0].x === snake[i].x && snake[0].y === snake[i].y){
            game_over();
        }
    }
}